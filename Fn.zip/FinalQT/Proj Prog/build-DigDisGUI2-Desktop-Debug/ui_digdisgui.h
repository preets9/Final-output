/********************************************************************************
** Form generated from reading UI file 'digdisgui.ui'
**
** Created by: Qt User Interface Compiler version 4.8.7
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIGDISGUI_H
#define UI_DIGDISGUI_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QFrame>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QMainWindow>
#include <QtGui/QMenuBar>
#include <QtGui/QPushButton>
#include <QtGui/QStatusBar>
#include <QtGui/QTextBrowser>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_DigDisGUI
{
public:
    QWidget *centralwidget;
    QLabel *label_3;
    QLabel *label_2;
    QPushButton *pushButton;
    QLabel *label;
    QPushButton *pushButton_2;
    QLabel *label_4;
    QLabel *label_5;
    QFrame *line;
    QTextBrowser *textBrowser;
    QPushButton *pushButton_3;
    QPushButton *pushButton_4;
    QPushButton *pushButton_5;
    QPushButton *pushButton_6;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *DigDisGUI)
    {
        if (DigDisGUI->objectName().isEmpty())
            DigDisGUI->setObjectName(QString::fromUtf8("DigDisGUI"));
        DigDisGUI->resize(1200, 1024);
        centralwidget = new QWidget(DigDisGUI);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        label_3 = new QLabel(centralwidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(80, 50, 481, 81));
        QFont font;
        font.setFamily(QString::fromUtf8("Elephant"));
        font.setPointSize(48);
        font.setBold(false);
        font.setWeight(50);
        font.setStrikeOut(false);
        label_3->setFont(font);
        label_2 = new QLabel(centralwidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(220, 10, 171, 51));
        QFont font1;
        font1.setFamily(QString::fromUtf8("Imprint MT Shadow"));
        font1.setPointSize(17);
        label_2->setFont(font1);
        pushButton = new QPushButton(centralwidget);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(120, 220, 361, 111));
        label = new QLabel(centralwidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(80, 120, 481, 71));
        QFont font2;
        font2.setFamily(QString::fromUtf8("Imprint MT Shadow"));
        font2.setPointSize(17);
        font2.setUnderline(false);
        label->setFont(font2);
        pushButton_2 = new QPushButton(centralwidget);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(120, 360, 361, 111));
        label_4 = new QLabel(centralwidget);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(60, 830, 491, 91));
        QFont font3;
        font3.setFamily(QString::fromUtf8("MV Boli"));
        font3.setPointSize(12);
        label_4->setFont(font3);
        label_5 = new QLabel(centralwidget);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(720, 10, 441, 16));
        QFont font4;
        font4.setFamily(QString::fromUtf8("Imprint MT Shadow"));
        font4.setPointSize(12);
        label_5->setFont(font4);
        line = new QFrame(centralwidget);
        line->setObjectName(QString::fromUtf8("line"));
        line->setGeometry(QRect(601, 0, 20, 991));
        QFont font5;
        font5.setBold(false);
        font5.setWeight(50);
        line->setFont(font5);
        line->setFrameShape(QFrame::VLine);
        line->setFrameShadow(QFrame::Sunken);
        textBrowser = new QTextBrowser(centralwidget);
        textBrowser->setObjectName(QString::fromUtf8("textBrowser"));
        textBrowser->setGeometry(QRect(630, 30, 551, 891));
        pushButton_3 = new QPushButton(centralwidget);
        pushButton_3->setObjectName(QString::fromUtf8("pushButton_3"));
        pushButton_3->setGeometry(QRect(940, 940, 251, 41));
        pushButton_4 = new QPushButton(centralwidget);
        pushButton_4->setObjectName(QString::fromUtf8("pushButton_4"));
        pushButton_4->setGeometry(QRect(630, 940, 251, 41));
        pushButton_5 = new QPushButton(centralwidget);
        pushButton_5->setObjectName(QString::fromUtf8("pushButton_5"));
        pushButton_5->setGeometry(QRect(530, 910, 51, 41));
        pushButton_6 = new QPushButton(centralwidget);
        pushButton_6->setObjectName(QString::fromUtf8("pushButton_6"));
        pushButton_6->setGeometry(QRect(120, 500, 361, 111));
        DigDisGUI->setCentralWidget(centralwidget);
        menubar = new QMenuBar(DigDisGUI);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 1200, 22));
        DigDisGUI->setMenuBar(menubar);
        statusbar = new QStatusBar(DigDisGUI);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        DigDisGUI->setStatusBar(statusbar);

        retranslateUi(DigDisGUI);

        QMetaObject::connectSlotsByName(DigDisGUI);
    } // setupUi

    void retranslateUi(QMainWindow *DigDisGUI)
    {
        DigDisGUI->setWindowTitle(QApplication::translate("DigDisGUI", "DigDisGUI", 0, QApplication::UnicodeUTF8));
        label_3->setText(QApplication::translate("DigDisGUI", "Dig-Disp  GUI", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("DigDisGUI", "WELCOME TO", 0, QApplication::UnicodeUTF8));
        pushButton->setText(QApplication::translate("DigDisGUI", "OPEN CALENDER", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("DigDisGUI", " (DIGITAL DISPOSE GUIDELINES BOOK)", 0, QApplication::UnicodeUTF8));
        pushButton_2->setText(QApplication::translate("DigDisGUI", "OPEN QUIZ", 0, QApplication::UnicodeUTF8));
        label_4->setText(QApplication::translate("DigDisGUI", "Project by: Gurkirat Singh, Damanpreet Singh, Harpreet Kaur", 0, QApplication::UnicodeUTF8));
        label_5->setText(QApplication::translate("DigDisGUI", "REGION OF PEEL GARBAGE COLLECTION MANUAL", 0, QApplication::UnicodeUTF8));
        pushButton_3->setText(QApplication::translate("DigDisGUI", "Close Manual", 0, QApplication::UnicodeUTF8));
        pushButton_4->setText(QApplication::translate("DigDisGUI", "Open Manual", 0, QApplication::UnicodeUTF8));
        pushButton_5->setText(QApplication::translate("DigDisGUI", "CLOSE", 0, QApplication::UnicodeUTF8));
        pushButton_6->setText(QApplication::translate("DigDisGUI", "MOBILE TEXT SETUP", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class DigDisGUI: public Ui_DigDisGUI {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIGDISGUI_H
