/********************************************************************************
** Form generated from reading UI file 'haltoncal.ui'
**
** Created by: Qt User Interface Compiler version 4.8.7
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_HALTONCAL_H
#define UI_HALTONCAL_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>

QT_BEGIN_NAMESPACE

class Ui_HaltonCal
{
public:
    QLabel *label;

    void setupUi(QDialog *HaltonCal)
    {
        if (HaltonCal->objectName().isEmpty())
            HaltonCal->setObjectName(QString::fromUtf8("HaltonCal"));
        HaltonCal->resize(1200, 1024);
        label = new QLabel(HaltonCal);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(0, 0, 1200, 1024));

        retranslateUi(HaltonCal);

        QMetaObject::connectSlotsByName(HaltonCal);
    } // setupUi

    void retranslateUi(QDialog *HaltonCal)
    {
        HaltonCal->setWindowTitle(QApplication::translate("HaltonCal", "Dialog", 0, QApplication::UnicodeUTF8));
        label->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class HaltonCal: public Ui_HaltonCal {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_HALTONCAL_H
