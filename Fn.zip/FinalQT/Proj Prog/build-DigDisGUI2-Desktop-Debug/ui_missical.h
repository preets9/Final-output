/********************************************************************************
** Form generated from reading UI file 'missical.ui'
**
** Created by: Qt User Interface Compiler version 4.8.7
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MISSICAL_H
#define UI_MISSICAL_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>

QT_BEGIN_NAMESPACE

class Ui_Missical
{
public:
    QLabel *label;

    void setupUi(QDialog *Missical)
    {
        if (Missical->objectName().isEmpty())
            Missical->setObjectName(QString::fromUtf8("Missical"));
        Missical->resize(1200, 1024);
        label = new QLabel(Missical);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(0, 0, 1200, 1024));

        retranslateUi(Missical);

        QMetaObject::connectSlotsByName(Missical);
    } // setupUi

    void retranslateUi(QDialog *Missical)
    {
        Missical->setWindowTitle(QApplication::translate("Missical", "Dialog", 0, QApplication::UnicodeUTF8));
        label->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class Missical: public Ui_Missical {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MISSICAL_H
