#include "toroncal.h"
#include "ui_toroncal.h"
#include <QPixmap>
#include <QLabel>

toroncal::toroncal(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::toroncal)
{
    ui->setupUi(this);
    QPixmap pix("/home/pi/Downloads/FinalQT/Toronto.png");
    ui->label->setPixmap(pix.scaled(1250,1100,Qt::KeepAspectRatio));
        
}

toroncal::~toroncal()
{
    delete ui;
}
